package com.redhat;

public class myRow {
    private String FirstName;
    private String LastName;

    
    // the constructor
    public myRow( String FirstName, String LastName) {
    
        this.FirstName = FirstName;
        this.LastName = LastName;
    }}